<?php $__env->startSection('title', 'تعديل صفحة'); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($results)): ?>
<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => ['admin.pages.update', $results->id], 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>


    <div class="form-group">
        <?php echo e(Form::label('title', 'العنوان', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('title', $results->title, ['class' => 'form-control' , 'placeholder' => 'العنوان'])); ?>

       
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> 
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('details', 'التفاصيل', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('details', $results->details, ['class' => 'form-control ckeditor', 'placeholder' => 'التفاصيل'])); ?>

      
            <?php if ($errors->has('details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('details'); ?> 
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('filetitle', 'عنوان الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('filetitle', $results->filetitle, ['class' => 'form-control', 'placeholder' => 'عنوان الملف المرفق'])); ?>


            <?php if ($errors->has('filetitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('filetitle'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>



    <div class="form-group">
        <?php echo e(Form::label('fileattachupload', 'الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="fileattachupload"  />          
        </div>
    </div>  


    <?php if($results->fileattach): ?>
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::checkbox('deletefileattach', 1, 0, ['id' => 'deletefileattach'])); ?>  حذف الملف
            <a href="<?php echo e(asset('storage/upload/'. $results->fileattach)); ?>" target="_blank" class="btn btn-warning">
                    <?php echo e($results->filetitle); ?>

                    </a>
        </div>
    </div>
    <?php endif; ?>


    <div class="form-group">
        <?php echo e(Form::label('photo', 'الصورة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="photo" accept="image/*"  />
            الصورة يجب أن تكون بالأبعاد التالية, عرض 1024 بيكسل وإرتفاع 768 بيكسل
        </div>
    </div>  

        
  

    <?php if($results->image): ?>
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <img src='<?php echo e(asset('storage/images/'.$results->image)); ?>' style="width:300px;" class="img-thumbnail">
        </div>
    </div>
    <?php endif; ?>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/pages/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>


</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/pages/edit.blade.php ENDPATH**/ ?>