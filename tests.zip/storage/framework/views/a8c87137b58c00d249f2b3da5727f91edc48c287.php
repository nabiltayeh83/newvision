<div class="section primary-section" id="service" >
            <div class="container">
                <!-- Start title section -->
                <div class="title">
                    <h1>خدماتنا</h1>
                </div>
                <div class="row-fluid"> 
                <?php if(count($categories) > 0): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                    <div class="centered service">
                            <div class="circle-border zoom-in">
                                <a href="" title="<?php echo e($c->title); ?>">
                                <img class="img-circle" src="<?php echo e(asset('images/'.$c->image)); ?>" alt="<?php echo e($c->title); ?>">
                            </div>
                            <h3><?php echo e($c->title); ?> (<span style="color:white; font-size:21pt;"><?php echo e(servicesCount($c->id)); ?></span>)</h3>
                            <p><?php echo e($c->details); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>    

                    

                   
                    

                </div>
            </div>
        </div><?php /**PATH D:\laravel_tests\newvision\resources\views/front/services.blade.php ENDPATH**/ ?>