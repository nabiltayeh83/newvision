
<div id="da-slider" class="da-slider">
    
        <div class="container">       
                <?php $__currentLoopData = $servicesSlider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="da-slide">
                                <a href="<?php echo e(route('details', $itm->id)); ?>" title="<?php echo e($itm->projectname); ?>">
                                        <h2><?php echo e(categoryName($itm->category_id)); ?></h2>
                                        <h4><?php echo e(\Illuminate\Support\Str::words($itm->projectname,11)); ?></h4>
                                        <div class="da-img">
                                                <img src="<?php echo e(asset('storage/images/thumb/'.$itm->image)); ?>" alt="<?php echo e($itm->projectname); ?>">
                                        </div>
                                </a>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                        <div class="da-arrows">
                                    <span class="da-arrows-prev"></span>
                                    <span class="da-arrows-next"></span>
                        </div>        
        </div>


</div><?php /**PATH D:\laravel_tests\newvision\resources\views/front/slider.blade.php ENDPATH**/ ?>