<?php $__env->startSection('title', $results->title); ?>

<?php $__env->startSection('content'); ?>

        <p><?php echo $results->details; ?></p>    
                   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/contact.blade.php ENDPATH**/ ?>