<?php $__env->startSection('title', 'صفحة غير متوفرة'); ?>

<?php $__env->startSection('content'); ?>

<p class="errorimg">
    <a href="<?php echo e(route('HomePage')); ?>">
    <img src="<?php echo e(asset('storage/images/404.png')); ?>">
    </a>               
</p>
                          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/errors/404.blade.php ENDPATH**/ ?>