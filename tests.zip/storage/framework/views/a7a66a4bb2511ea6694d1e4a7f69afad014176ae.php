<?php $__env->startSection('title','الطلبات الواردة'); ?>

<?php $__env->startSection("content"); ?>

  
    <?php if($results->count()>0): ?>
    <?php $i=1; ?>
    <table class="table table-hover table-striped">
    	<thead>
        	<tr>
                <th>#</th>
            	<th>إسم المؤسسة</th>
                <th>الإسم كاملاً</th>
                <th>الهاتف</th>
                <th>نوع الخدمة</th>
                <th>البريد الإلكتروني</th>
                <th>التاريخ</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($i++); ?>-</th>
                <td><?php echo e($r->companyname); ?></td>
                <td><?php echo e($r->fullname); ?></td>
                <td><?php echo e($r->phone); ?></td>
                <td><?php echo e($r->categoryname->title); ?></td>
                <td><?php echo e($r->email); ?></td>
                <td><?php echo e(substr($r->created_at, 0, 10)); ?></td>
                <th>
                    <a href="<?php echo e(asset('admin/orders/'.$r->id)); ?>" class="btn btn-primary" title="إستعراض التفاصيل">
                    	<i class="glyphicon glyphicon-eye-open"></i>
                    </a>
                </th>
            	<td>
                	<a href="<?php echo e(asset('admin/orders/delete/'.$r->id)); ?>" class="btn Confirm btn-danger" title="حذف">
                    	<i class="glyphicon glyphicon-trash"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($results->links()); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("back.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/orders/index.blade.php ENDPATH**/ ?>