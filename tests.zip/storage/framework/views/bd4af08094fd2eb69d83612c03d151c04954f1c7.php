<?php $__env->startSection('title', $results->title); ?>

<?php $__env->startSection('content'); ?>

               
        <p><?php echo $results->details; ?></p>    
               
        <?php if($results->fileattach): ?>
            <a href="storage/upload/<?php echo e($results->fileattach); ?>" target="_blank" class="button">
            <?php echo e($results->filetitle); ?>

            </a>
        <?php endif; ?>
                
                          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/about.blade.php ENDPATH**/ ?>