<?php $__env->startSection('title', 'اطلب الخدمة'); ?>



<?php $__env->startSection('content'); ?>

    <?php
        $links = "اطلب الخدمة";
    ?>
    


            <div class="col-md-2"></div>
            
            <div class="col-md-8">

                <?php if($errors->count() >0): ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            - <?php echo e($error); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                
                <?php if(Session::get("msg")!=NULL): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(substr(Session::get("msg"),2)); ?><br><br>
                    </div>  
                <?php endif; ?>


                <?php echo Form::open(['route' => 'order', 'method' => 'POST', 'files' => 'true' , 'id' => 'artical_form']); ?>

                <?php echo e(csrf_field()); ?>


                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('companyname', old('companyname'), ['class' => 'span8', 'placeholder' => '* إسم المؤسسة', 'title' => '* إسم المؤسسة'])); ?>

                            <?php if ($errors->has('companyname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('companyname'); ?>
                                <span><?php echo e($message); ?><span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>


                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('fullname', old('fullname'), ['class' => 'span8', 'placeholder' => '* الإسم الكامل', 'title' => '* الإسم الكامل'])); ?>

                            <?php if ($errors->has('fullname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fullname'); ?>
                                <span><?php echo e($message); ?><span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div>
                    </div>


                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('email', old('email'), ['class' => 'span8', 'placeholder' => '* البريد الإلكتروني', 'title' => '* البريد الإلكتروني'])); ?>

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span><?php echo e($message); ?><span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                
        
                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('phone', old('phone'), ['class' => 'span8', 'placeholder' => '*  الهاتف', 'title' => '*  الهاتف'])); ?>

                            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                <span><?php echo e($message); ?><span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
            

                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('facebookaccount', old('facebookaccount'), ['class' => 'span8', 'placeholder' => 'رابط الفيسبوك', 'title' => 'رابط الفيسبوك'])); ?>

                        </div>
                    </div>
        

                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::text('twitteraccount', old('twitteraccount'), ['class' => 'span8', 'placeholder' => 'رابط تويتر', 'title' => 'رابط تويتر'])); ?>

                        </div>
                    </div>
                                        
        
                    <div class="control-group">
                        <div class="controls">
                        <?php echo e(Form::select('category_id', $categories, 1, ['class' => 'span8'])); ?>

                        </div>
                    </div>
                
        
                    <div class="control-group">
                        <div class="controls">
                            <?php echo e(Form::textarea('details', old('details'), ['class' => 'span8', 'placeholder' => 'تفاصيل الطلب', 'title' => 'تفاصيل الطلب'])); ?>

                            <?php if ($errors->has('details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('details'); ?>
                                <span><?php echo e($message); ?><span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
        
        
                    <div class="control-group">
                        <div class="controls">
                            <button id="send-mail" class="button">إرسال الطلب</button>
                        </div>
                    </div>
                                    
                <?php echo Form::close(); ?>


            </div>

            <div class="col-md-2"></div>



           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/orders.blade.php ENDPATH**/ ?>