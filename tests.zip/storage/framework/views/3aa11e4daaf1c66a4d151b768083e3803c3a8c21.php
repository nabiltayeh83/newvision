<?php $__env->startSection('title','إدارة المستخدمين'); ?>

<?php $__env->startSection("content"); ?>

        <div class="col-sm-12 text-right">
            <a class="btn btn-success" href="<?php echo e(asset('admin/users/create')); ?>">
            <i class="glyphicon glyphicon-plus"></i>
          اضافة مستخدم جديد
        </a>
        </div>
      <hr>
    
	<?php if($results->count()>0): ?>
    <table class="table table-hover table-striped">
    	<thead>
        	<tr>
                <th>الإسم</th>
            	<th>البريد الإلكتروني</th>
                <th>تاريخ الاضافة</th>
            	<th></th>
            </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($r->name); ?></td>
                <td><?php echo e($r->email); ?></td>
                <td><?php echo e(substr($r->created_at, 0, 10)); ?></td>
            	<td>

                

                    <?php if($r->email != 'nabil_9000@hotmail.com'): ?>
                	<a title='صلاحيات - <?php echo e($r->name); ?>' href="<?php echo e(asset('admin/users/permission/'.$r->id)); ?>"
                     class="btn btn-warning">
                    	<i class="glyphicon glyphicon-lock"></i>
                    </a>
                    <?php endif; ?>
               

                	<a href="<?php echo e(asset('admin/users/'.$r->id.'/edit')); ?>" class="btn btn-primary">
                    	<i class="glyphicon glyphicon-edit"></i>
                    </a>

                    <?php if($r->email != 'nabil_9000@hotmail.com'): ?>
                	<a href="<?php echo e(asset('admin/users/delete/'.$r->id)); ?>" class="btn Confirm btn-danger">
                    	<i class="glyphicon glyphicon-trash"></i>
                    </a>
                    <?php endif; ?>
                

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($results->links()); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("back.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/users/index.blade.php ENDPATH**/ ?>