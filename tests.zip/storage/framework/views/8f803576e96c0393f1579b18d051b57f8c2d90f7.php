<?php echo e($slot); ?>

<?php /**PATH D:\laravel_tests\newvision\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>