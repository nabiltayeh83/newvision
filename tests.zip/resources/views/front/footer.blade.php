<div class="footer">
        <p> جميع الحقوق محفوظة - 
                @if(isset($sitesettings->title)) 
                        {{$sitesettings->title}} 
                @endif {{date('Y')}}  &copy;
        </p>
</div>


<div class="scrollup">
        <a href="#">
                <i class="icon-up-open"></i>
        </a>
</div>