<?php $__env->startSection('title', 'الرئيسية'); ?>



<?php $__env->startSection('content'); ?>

    <?php if(count($servicesSlider) > 0): ?>
        <?php echo $__env->make('front.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
            

    <?php if(count($lastServices) > 0): ?>
        <div class="wrapper">
            <ul class="auto-grid">
                <?php $__currentLoopData = $lastServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('front.layouts.showservices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/index.blade.php ENDPATH**/ ?>