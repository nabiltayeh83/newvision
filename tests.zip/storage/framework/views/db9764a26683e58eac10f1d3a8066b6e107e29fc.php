

<li>
        <div class="imgcontainer">
                <a href="<?php echo e(route('details', $itm->id)); ?>" class='overlayproname' title="<?php echo e($itm->projectname); ?>">
                        <img src="<?php echo e(asset('storage/images/thumb/'.$itm->image)); ?>" alt="<?php echo e($itm->projectname); ?>" class="imageeffect">
                        <div class="overlay">
                                <?php echo e(\Illuminate\Support\Str::words($itm->projectname,12)); ?>

                                <h3 class="margin-t10per"><a href="<?php echo e(route('category')); ?>">خدماتنا</a> / 
                                <a href="<?php echo e(route('services', $itm->category_id)); ?>"><?php echo e(categoryName($itm->category_id)); ?></a>
                                </h3>
                        </div>
                </a>
        </div>
</li><?php /**PATH D:\laravel_tests\newvision\resources\views/front/layouts/showservices.blade.php ENDPATH**/ ?>