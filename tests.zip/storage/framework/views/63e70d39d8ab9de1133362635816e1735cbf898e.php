<?php $__env->startSection('title', 'إدارة التصنيفات'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12">

    <div class="panel panel-default">

        <div class="panel-heading">
            <form method="get" action="<?php echo e(asset('admin/categories')); ?>" class="row">
                <div class="col-sm-12 text-right">
                <a class="btn btn-success" href="<?php echo e(asset('admin/categories/create')); ?>">
                <i class="glyphicon glyphicon-plus"></i> إضافة تصنيف جديد</a>
                </div>
            </form>
        </div>
    
<div class="panel-body">

<div class="table-responsive">
<?php if(count($results) > 0): ?>
<table class="table table-striped table-boredered table-hover table-responsive">
    <thead>
    <tr>
        <th>#</th>
        <th style="width:20%;">التصنيف</th>
        <th style="width:50%;">الوصف</th>
        <th>فعال</th>
        <th>الصورة</th>
        <th></th>
        <th></th>
    </tr>
    </thead>

    <?php $i=1; ?>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i++); ?></th>
        <td><?php echo e($r->title); ?></td>
        <td><?php echo e($r->description); ?></td>
        <td><input type="checkbox" value="<?php echo e($r->id); ?>" class="cbActive" <?php echo e($r->is_active?"checked":""); ?>></td>
        <td><img src="<?php echo e(asset('storage/images/' . $r->image)); ?>" style="height:90px;"></td>
        <td><a href="<?php echo e(asset('admin/categories/' . $r->id . '/edit')); ?>" class="btn btn-primary" title="تعديل">
        <span class="glyphicon glyphicon-edit"></span></a></td>
        <td><a href="<?php echo e(asset('admin/categories/delete/' . $r->id)); ?>" class="btn Confirm btn-danger" title="حذف">
        <span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php else: ?>
<div>
عذراً... لا يوجد أي نتائج
</div>
<?php endif; ?>

</div>
</div>
</div>
</div>
</div>

<script>
    $(function(){
        $(".cbActive").click(function(){
            var id=$(this).val();
            $.get("/admin/categories/active/"+id);
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/categories/index.blade.php ENDPATH**/ ?>