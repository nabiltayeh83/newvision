<?php $__env->startSection('title', 'تعديل خدمة'); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($results)): ?>
<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => ['admin.services.update', $results->id], 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>




         
    <div class="form-group">
        <?php echo e(Form::label('projectname', 'اسم المشروع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('projectname', $results->projectname, ['class' => 'form-control', 'placeholder' => 'اسم المشروع'])); ?>

        
            <?php if ($errors->has('projectname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('projectname'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('customername', 'اسم العميل', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('customername', $results->customername, ['class' => 'form-control', 'placeholder' => 'اسم العميل'])); ?>

        
            <?php if ($errors->has('customername')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customername'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('category_id', 'التصنيف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::select('category_id', $categories, $results->category_id, ['class' => 'form-control', 'style' => 'padding:5px;'])); ?>

        </div>
    </div>   


    <div class="form-group">
        <?php echo e(Form::label('stages', 'مراحل العمل', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('stages', $results->stages, ['class' => 'form-control', 'placeholder' => 'مراحل العمل', 'style' => 'height:70px;'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('period', 'مدة التنفيذ', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('period', $results->period, ['class' => 'form-control', 'placeholder' => 'مدة التنفيذ'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('year', 'السنة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('year', $results->year, ['class' => 'form-control', 'placeholder' => 'السنة'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('vedio', 'الفيديو', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('vedio', $results->vedio, ['class' => 'form-control', 'placeholder' => 'الفيديو', 'style' => 'height:70px;'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('filetitle', 'عنوان الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('filetitle', $results->filetitle, ['class' => 'form-control', 'placeholder' => 'عنوان الملف المرفق'])); ?>


            <?php if ($errors->has('filetitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('filetitle'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('fileattachupload', 'الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="fileattachupload"  />          
        </div>
    </div>  


    <?php if($results->fileattach): ?>
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::checkbox('deletefileattach', 1, 0, ['id' => 'deletefileattach'])); ?>  حذف الملف
            <a href="<?php echo e(asset('storage/upload/'. $results->fileattach)); ?>" target="_blank" class="btn btn-warning">
                    <?php echo e($results->filetitle); ?>

                    </a>
        </div>
    </div>
    <?php endif; ?>
 
    
    <div class="form-group">
        <?php echo e(Form::label('album', 'ألبوم الصور', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="album[]" accept="image/*" multiple />
        </div>
    </div>  

    <?php if($results->images->count() > 0): ?>
    <div class="form-group">
        <?php echo e(Form::label('album', 'حذف صور', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
        <table class="table table-striped table-responsive">
        <?php $i=0;  ?>
        <tr>
        <?php $__currentLoopData = $results->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $i++;  ?>

        <td><input type="checkbox" name="oldimages[]" id="<?php echo e($img->id); ?>" value="<?php echo e($img->id); ?>"></td>
        <td><label for="<?php echo e($img->id); ?>">
        <img src='<?php echo e(asset('storage/images/'.$img->image)); ?>' style="width:110px;" class="img-thumbnail">
        </label>
        </td>

        <?php if($i%5 ==0): ?> </tr><tr> <?php endif; ?>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
    </div>  
    <?php endif; ?>

    <div class="form-group">
        <?php echo e(Form::label('imagefile', 'الصورة الرئيسية', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="imagefile" accept="image/*"  />
            الصورة الرئيسية يجب أن تكون بالأبعاد التالية, عرض 1024 بيكسل وإرتفاع 768 بيكسل
            <br><img src="<?php echo e(asset('storage/images/' . $results->image)); ?>" style="width:150px;" class="margin-t10">
        </div>
    </div>  

        
    <div class="form-group">
        <?php echo e(Form::label('is_active', 'فعال', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::checkbox('is_active', 1, $results->is_active, ['id' => 'is_active'])); ?>

        </div>
    </div>
 
    


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/services/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>





</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/services/edit.blade.php ENDPATH**/ ?>