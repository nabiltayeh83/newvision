<?php $__env->startSection('title', 'صفحة غير متوفرة'); ?>

<?php $__env->startSection('content'); ?>

<p class="errorimg">
    <a href="<?php echo e(route('home')); ?>">
    <img src="<?php echo e(asset('storage/images/404.png')); ?>">
    </a>               
</p>
                          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/errors/403.blade.php ENDPATH**/ ?>