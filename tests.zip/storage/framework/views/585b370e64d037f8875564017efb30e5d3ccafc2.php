<div class="navbar">    
<div class="navbar-inner">
<div class="container">


    <a href="<?php echo e(route('HomePage')); ?>" class="brand">
        <?php if(isset($sitesettings->logo)): ?>
                    <img src="<?php echo e(asset('storage/images/'.$sitesettings->logo)); ?>" 
                    alt="<?php echo e($sitesettings->title); ?>" />
        <?php endif; ?>
    </a>
            
    <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <i class="icon-menu"></i>
    </button>
                    
    <div class="nav-collapse margin-t15 collapse pull-right">
            <ul class="nav" style="direction:rtl;">
                <li class="active"><a href="<?php echo e(route('HomePage')); ?>">الرئيسية</a></li>
                <li><a href="<?php echo e(route('pages', 1)); ?>">عن الشركة</a></li>
                <li><a href="<?php echo e(route('category')); ?>">خدماتنا</a></li>
                <li><a href="<?php echo e(route('order')); ?>">اطلب الخدمة</a></li>
                <li><a href="<?php echo e(route('pages', 2)); ?>">إتصل بنا</a></li>
            </ul>
    </div>

            
</div>
</div>
</div><?php /**PATH D:\laravel_tests\newvision\resources\views/front/navbar.blade.php ENDPATH**/ ?>