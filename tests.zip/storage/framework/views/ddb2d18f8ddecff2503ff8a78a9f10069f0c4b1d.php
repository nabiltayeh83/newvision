<?php $__env->startSection('title', 'إعدادات الموقع'); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($results)): ?>
<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => ['admin.sitesettings.update', $results->id], 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>


    <div class="form-group">
        <?php echo e(Form::label('title', 'العنوان - إسم الموقع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('title', $results->title, ['class' => 'form-control' , 'placeholder' => 'العنوان - إسم الموقع'])); ?>

            
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('description', 'وصف الموقع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('description', $results->description, ['class' => 'form-control', 'placeholder' => 'وصف الموقع', 'style' => 'height:90px;'])); ?>

        
            <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('text', 'الكلمات المفتاحية', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('keywords', $results->keywords, ['class' => 'form-control', 'placeholder' => 'الكلمات المفتاحية', 'style' => 'height:90px;'])); ?>

            
            <?php if ($errors->has('keywords')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keywords'); ?>
                <strong><?php echo e($message); ?></strong><br>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            
            <span style="color:red">
            يجب الفصل بين كل كلمة مفتاحية و الأخرى بفاصلة, مثلا:
            تصميم, مونتاج, تصوير</span><br><br>
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('siteicofile', 'أيقون الموقع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="siteicofile" accept="image/*"  />
            <span style="color:red">
              الأيقون يجب أن يكون بالأبعاد التالية, إرتفاع 16 بيكسل, عرض 16 بيكسل.</span><br>
            <?php if($results->siteico): ?>  
            <img src="<?php echo e(asset('storage/images/'.$results->siteico)); ?>"><br><br>
            <?php endif; ?>
        </div>
    </div>  


    <div class="form-group">
        <?php echo e(Form::label('logofile', 'شعار الموقع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="logofile" accept="image/*" />
            
            <span style="color:red"> شعار الموقع يجب أن يكون بالأبعاد التالية, إرتفاع 80 بيكسل, عرض 240 بيكسل</span><br>
            <?php if($results->logo): ?>
            <img src="<?php echo e(asset('storage/images/'.$results->logo)); ?>" style="width:240px; height:80px;">
            <?php endif; ?>
        </div>
    </div>  


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/sitesettings/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>


</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/sitesettings/edit.blade.php ENDPATH**/ ?>