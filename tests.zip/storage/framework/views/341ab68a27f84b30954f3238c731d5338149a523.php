<?php $__env->startSection('title', "تعديل صلاحيات المستخدم / $results->name"); ?>

<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-md-8">

<?php echo Form::open(array('files' => 'true', 'id' => $results->id)); ?>

            <?php echo e(csrf_field()); ?>


    <label>
    <input <?php echo e($results->hasPermissionTo('Sitesettings')?"checked":""); ?> type="checkbox" name="permission[1]" value="Sitesettings">
    <b>إعدادات الموقع</b></label><br>        
               
    <label>
    <input <?php echo e($results->hasPermissionTo('Categories')?"checked":""); ?> type="checkbox" name="permission[2]" value="Categories">
    <b>إدارة التصنيفات</b></label><br>

    <label>
    <input <?php echo e($results->hasPermissionTo('Services')?"checked":""); ?> type="checkbox" name="permission[3]" value="Services">
    <b>إدارة الخدمات</b></label><br>    

    <label>
    <input <?php echo e($results->hasPermissionTo('Pages')?"checked":""); ?> type="checkbox" name="permission[4]" value="Pages">
    <b>إدارة الصفحات</b></label><br>   


    <label>
    <input <?php echo e($results->hasPermissionTo('Orders')?"checked":""); ?> type="checkbox" name="permission[5]" value="Orders">
    <b>الطلبات الواردة</b></label><br>   


    <label>
    <input <?php echo e($results->hasPermissionTo('Users')?"checked":""); ?> type="checkbox" name="permission[6]" value="Users">
    <b>إدارة المستخدمين</b></label><br>

                    <button type="submit" class="btn btn-primary">حفظ</button>
                    <a class="btn btn-default" href="<?php echo e(asset('admin/users')); ?>">الغاء الأمر</a>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("back.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/users/permission.blade.php ENDPATH**/ ?>