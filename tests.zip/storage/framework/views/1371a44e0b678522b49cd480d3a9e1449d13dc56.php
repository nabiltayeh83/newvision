<div id="contact" class="contact">
            <div class="section secondary-section">
                <div class="container">
                    <div class="title">
                        <h1><?php echo e($contactus->title); ?></h1>
                    </div>
                    <div>
               <p><?php echo $contactus->details; ?></p>    
               </div>
                </div>
               
           
        </div>
</div><?php /**PATH D:\laravel_tests\newvision\resources\views/front/layouts/contact.blade.php ENDPATH**/ ?>