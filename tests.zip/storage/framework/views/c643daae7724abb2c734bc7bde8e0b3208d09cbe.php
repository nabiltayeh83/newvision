<?php $__env->startSection('title', 'عرض تفاصيل الطلب'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => ['admin.services.update', $results->id], 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>


    <div class="form-group">
        <?php echo e(Form::label('projectname', 'تاريخ الطلب', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(substr($results->created_at, 0, 10)); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('projectname', 'اسم المؤسسة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->companyname); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('customername', 'الإسم كاملاً', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->fullname); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('category_id', 'البريد الإلكتروني', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->email); ?>

        </div>
    </div>   


    <div class="form-group">
        <?php echo e(Form::label('stages', 'الهاتف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->phone); ?>

        </div>
    </div>


    <?php if($results->facebookaccount): ?>
    <div class="form-group">
        <?php echo e(Form::label('period', 'رابط فيسبوك', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <a href="<?php echo e($results->facebookaccount); ?>" target="_blank">
                <?php echo e($results->facebookaccount); ?>

            </a>
        </div>
    </div>
    <?php endif; ?>


    <?php if($results->twitteraccount): ?>
    <div class="form-group">
        <?php echo e(Form::label('period', 'رابط تويتر', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <a href="<?php echo e($results->twitteraccount); ?>" target="_blank">
                <?php echo e($results->twitteraccount); ?>

            </a>
        </div>
    </div>
    <?php endif; ?>


    <div class="form-group">
        <?php echo e(Form::label('year', 'نوع الخدمة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->categoryname->title); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('vedio', 'تفاصيل الطلب', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e($results->details); ?>

        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">

            <a href="<?php echo e(asset('admin/orders/delete/'.$results->id)); ?>" class="btn Confirm btn-danger" title="حذف">
                <i class="glyphicon glyphicon-trash"></i> حذف الطلب
            </a>

            <a href="<?php echo e(asset('admin/orders/')); ?>" class="btn btn-primary" title="إستعراض الطلبات">
                 إستعراض الطلبات
            </a>

        </div>
    </div>

<?php echo Form::close(); ?>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/orders/show.blade.php ENDPATH**/ ?>