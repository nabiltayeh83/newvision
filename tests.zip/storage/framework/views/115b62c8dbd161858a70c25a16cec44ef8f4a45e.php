<?php $__env->startSection('title', "$results->projectname"); ?>

<?php $__env->startSection('content'); ?>


    <?php
        $links = "<a href='\category'>" . "خدماتنا" . "</a> / <a href='\services/$results->category_id'>" . categoryName($results->category_id) . "</a>";
    ?>

    <?php if($results): ?>
        <div class="col-md-12">
            <div class="centered service">

                <div class="margin-b15">
                    <?php if($results->vedio): ?>
                        <?php echo $results->vedio; ?>

                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/images/'.$results->image)); ?>">
                    <?php endif; ?>
                </div>

                <div>اسم المشروع: <span class="prodet"><?php echo e($results->projectname); ?></span></div>
                <div>اسم العميل: <span class="prodet"><?php echo e($results->customername); ?></span></div>
                <div>التصنيف: <span class="prodet"><?php echo e(categoryName($results->category_id)); ?></span></div>

                <?php if($results->stages): ?>
                    <div>مراحل العمل: <span class="prodet"><?php echo e($results->stages); ?></span></div>
                <?php endif; ?>

                <?php if($results->period): ?>
                    <div>مدة التنفيذ: <span class="prodet"><?php echo e($results->period); ?></span></div>
                <?php endif; ?>    

                <?php if($results->year): ?>    
                    <div>السنة: <span class="prodet"><?php echo e($results->year); ?></span></div>
                <?php endif; ?>

                <?php if(count($results->images) > 0): ?>
                <div>
                    <?php $__currentLoopData = $results->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/images/'.$img->image)); ?>" class="margin-t15">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>    
                <?php endif; ?>
                

                <?php if($results->fileattach): ?>
                <div class="margin-t15">
                    <br><h3>الملف المرفق</h3>
                    <a href="<?php echo e(asset('storage/upload/'. $results->fileattach)); ?>" target="_blank" class="button">
                        <?php echo e($results->filetitle); ?>

                    </a>
                </div>    
                <?php endif; ?>


            </div>
        </div>
    <?php endif; ?>    
                               

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/details.blade.php ENDPATH**/ ?>