<?php $__env->startSection('title', 'إضافة تصنيف جديد'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => 'admin.categories.store', 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>


    <div class="form-group">
        <?php echo e(Form::label('title', 'التصنيف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('title', old('title'), ['class' => 'form-control', 'placeholder' => 'التصنيف'])); ?>

       
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                <strong><?php echo e($message); ?></strong><br>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('description', 'الوصف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control', 'placeholder' => 'التصنيف', 'style' => 'height:70px;'])); ?>

        
        
            <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                <strong><?php echo e($message); ?></strong><br>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('imagefile', 'الصورة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="imagefile" accept="image/*" required />
        </div>
    </div>  


    <div class="form-group">
        <?php echo e(Form::label('is_active', 'فعال', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::checkbox('is_active', 1, 1, ['id' => 'is_active'])); ?>

        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/categories/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/categories/create.blade.php ENDPATH**/ ?>