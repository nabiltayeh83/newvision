<?php

return [
    'Login' => 'تسجيل الدخول',
    'E-Mail-Address' => 'البريد الإلكتروني',
    'Password' => 'كلمة المرور',
    'Confirm_Password' => 'تأكيد كلمة المرور',
    'Remember_Me' => 'تذكرني',
    'Forgot_Your _Password?' => 'نسيت كلمة المرور؟',
    'Register' => 'مستخدم جديد',
    'Name' => 'الإسم',
    'Reset_Password' => 'إستعادة كلمة المرور',
    'Send_Password_Reset_Link' => 'إرسال رابط إعادة تعيين كلمة المرور'
];