<?php $__env->startSection('title', 'تعديل تصنيف'); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($results)): ?>
<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => ['admin.categories.update', $results->id], 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>



    <div class="form-group">
        <?php echo e(Form::label('title', 'التصنيف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('title', $results->title, ['class' => 'form-control', 'placeholder' => 'التصنيف'])); ?>

        
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                <strong><?php echo e($message); ?></strong><br>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('description', 'الوصف', ['class' => 'col-sm-3'])); ?>

        
        <div class="col-sm-9">
            <?php echo e(Form::textarea('description', $results->description, ['class' => 'form-control', 'placeholder' => 'الوصف', 'style' => 'height:80px;'])); ?>

       
            <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                <strong><?php echo e($message); ?></strong><br>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('imagefile', 'الصورة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="imagefile" accept="image/*" />
            <br>
            <?php if(isset($results->image)): ?>
                <img src="<?php echo e(asset('storage/images/' . $results->image)); ?>" style="height:110px;">
            <?php endif; ?>
        </div>
    </div>  


    
    <div class="form-group">
        <?php echo e(Form::label('is_active', 'فعال', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::checkbox('is_active', 1, $results->is_active, ['id' => 'is_active'])); ?>

        </div>
    </div>



    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/categories/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>





</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/categories/edit.blade.php ENDPATH**/ ?>