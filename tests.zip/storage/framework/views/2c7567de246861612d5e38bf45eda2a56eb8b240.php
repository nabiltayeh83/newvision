<?php $__env->startSection('title', 'إضافة خدمة جديدة'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="panel panel-default">
<div class="panel-body">


<?php echo Form::open(['route' => 'admin.services.store', 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>



    <div class="form-group">
        <?php echo e(Form::label('projectname', 'اسم المشروع', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('projectname', old('projectname'), ['class' => 'form-control', 'placeholder' => 'اسم المشروع'])); ?>

        
            <?php if ($errors->has('projectname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('projectname'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('customername', 'اسم العميل', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('customername', old('customername'), ['class' => 'form-control', 'placeholder' => 'اسم العميل'])); ?>

        
            <?php if ($errors->has('customername')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customername'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('category_id', 'التصنيف', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::select('category_id', $categories, 1, ['class' => 'form-control', 'style' => 'padding:5px;'])); ?>

        </div>
    </div>   


    <div class="form-group">
        <?php echo e(Form::label('stages', 'مراحل العمل', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('stages', old('stages'), ['class' => 'form-control', 'placeholder' => 'مراحل العمل', 'style' => 'height:70px;'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('period', 'مدة التنفيذ', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('period', old('period'), ['class' => 'form-control', 'placeholder' => 'مدة التنفيذ'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('year', 'السنة', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('year', old('year'), ['class' => 'form-control', 'placeholder' => 'السنة'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('vedio', 'الفيديو', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::textarea('vedio', old('vedio'), ['class' => 'form-control', 'placeholder' => 'الفيديو', 'style' => 'height:70px;'])); ?>

        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('filetitle', 'عنوان الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::text('filetitle', old('filetitle'), ['class' => 'form-control', 'placeholder' => 'عنوان الملف المرفق'])); ?>


            <?php if ($errors->has('filetitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('filetitle'); ?>
                <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
       
        </div>
    </div>


    <div class="form-group">
        <?php echo e(Form::label('fileattachupload', 'الملف المرفق', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="fileattachupload"  />
        </div>
    </div>  
 
    
    <div class="form-group">
        <?php echo e(Form::label('album', 'ألبوم الصور', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="album[]" accept="image/*" multiple />
        </div>
    </div>  

    <div class="form-group">
        <?php echo e(Form::label('imagefile', 'الصورة الرئيسية', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <input type="file" class="form-control" name="imagefile" accept="image/*" required />
            الصورة الرئيسية يجب أن تكون بالأبعاد التالية, عرض 1024 بيكسل وإرتفاع 768 بيكسل
        </div>
    </div>  

        
    <div class="form-group">
        <?php echo e(Form::label('is_active', 'فعال', ['class' => 'col-sm-3'])); ?>

        <div class="col-sm-9">
            <?php echo e(Form::checkbox('is_active', 1, 1, ['id' => 'is_active'])); ?>

        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-9">
            <?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(asset('admin/services/')); ?>" class="btn btn-default">إلغاء</a>
        </div>
    </div>

<?php echo Form::close(); ?>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/services/create.blade.php ENDPATH**/ ?>