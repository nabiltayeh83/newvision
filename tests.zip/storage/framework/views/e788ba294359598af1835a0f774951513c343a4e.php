<?php $__env->startSection("content"); ?>
<div class="row">
	<div class="col-md-8">


<?php echo Form::open(['route' => 'admin.users.store', 'method' => 'POST', 'files' => 'true' , 'class' => 'form-horizontal', 
'id' => 'artical_form']); ?>

<?php echo e(csrf_field()); ?>


          <div class="form-group">
            <label for="name" class="col-sm-3 control-label">الإسم بالكامل </label>
            <div class="col-sm-9">
              <input value="<?php echo e(old("name")); ?>" type="text" class="form-control" id="name" name="name" placeholder="الإسم">
            </div>
          </div>

    

          <div class="form-group">
            <label for="email" class="col-sm-3 control-label">البريد الإلكتروني </label>
            <div class="col-sm-9">
              <input value="<?php echo e(old("email")); ?>" type="email" class="form-control" id="email" name="email" placeholder="البريد الإلكتروني">
            </div>
          </div>
            
        <div class="form-group">
            <label for="passwordunc" class="col-sm-3 control-label">كلمة المرور</label>
            <div class="col-sm-9">
                <input type="text" value="<?php echo e(old("passwordunc")); ?>" class="form-control" name="passwordunc" id="passwordunc" placeholder="كلمة المرور" required>
            </div>
        </div>

   

          <div class="form-group">
            <div class="col-sm-offset-3 col-sm-9">
              <button type="submit" class="btn btn-primary">اضافة</button>
              <a class="btn btn-default" href="<?php echo e(asset('admin/users')); ?>">الغاء الأمر</a>
            </div>
          </div>
            </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

























<?php $__env->startSection("title"); ?>
اضافة مستخدم جديد
<?php $__env->stopSection(); ?>



<?php echo $__env->make("back.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/users/create.blade.php ENDPATH**/ ?>