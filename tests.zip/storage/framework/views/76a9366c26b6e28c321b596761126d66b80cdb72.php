<?php $__env->startSection('title', $results->title); ?>


<?php $__env->startSection('content'); ?>
                <?php
                    $links = $results->title;
                ?>

            <?php if($results->image): ?>
                <img src="<?php echo e(asset('storage/images/'.$results->image)); ?>" class="page-img">
            <?php endif; ?>

            <p><?php echo $results->details; ?></p>

            <?php if($results->fileattach): ?>
                    <h3>الملف المرفق</h3>
                    <a href="<?php echo e(asset('storage/upload/'. $results->fileattach)); ?>" target="_blank" class="button">
                            <?php echo e($results->filetitle); ?>

                    </a>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/pages.blade.php ENDPATH**/ ?>