<?php $__env->startSection('title', 'إدارة الصفحات'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12">

    <div class="panel panel-default">


    
<div class="panel-body">

<div class="table-responsive">
<?php if(count($results) > 0): ?>
<table class="table table-striped table-boredered table-hover table-responsive">
    <thead>
    <tr>
        <th>#</th>
        <th style="width:30%;">العنوان</th>
        <th>تاريخ آخر تحديث</th>
        <th>الصورة</th>
        <th></th>
    </tr>
    </thead>

    <?php $i=1; ?>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i++); ?></th>
        <td><?php echo e($r->title); ?>


        </td>
        <td><?php echo e(substr($r->updated_at, 0, 10)); ?></td>
        <td><img src="<?php echo e(asset('storage/images/'.$r->image)); ?>" class="img-thumbnail" style="width:80px;"></td>
        <td><a href="<?php echo e(asset('admin/pages/' . $r->id . '/edit')); ?>" class="btn btn-primary" title="تعديل">
        <span class="glyphicon glyphicon-edit"></span></a></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php else: ?>
<div>
عذراً... لا يوجد أي نتائج
</div>
<?php endif; ?>

</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/pages/index.blade.php ENDPATH**/ ?>