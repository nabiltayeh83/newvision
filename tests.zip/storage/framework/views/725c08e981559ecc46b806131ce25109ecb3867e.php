<?php $__env->startSection('title', 'خدماتنا'); ?>


<?php $__env->startSection('content'); ?>

        <?php $links = "خدماتنا"; ?>
                            
        <?php if(count($results) > 0): ?>
                <div class="wrapper-three">
                        <ul class="auto-grid-three">
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('services', $r->id)); ?>" title="<?php echo e($r->title); ?>">
                                                    <div class="circle-border zoom-in">
                                                            <img class="img-circle" src="<?php echo e(asset('storage/images/'.$r->image)); ?>" alt="<?php echo e($r->title); ?>">
                                                    </div>
                                                    <h3><?php echo e($r->title); ?> (<?php echo e(servicesCount($r->id)); ?>)</h3>
                                                    <p id="cat_des"><?php echo e($r->description); ?></p>
                                            </a>
                                        </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
        <?php else: ?>
                <h2 id="errorimg-h2">نأسف!! لا يوجد أي نتائج</h2>
        <?php endif; ?>             

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/front/category.blade.php ENDPATH**/ ?>