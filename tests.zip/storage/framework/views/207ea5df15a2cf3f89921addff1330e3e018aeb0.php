<div class="section primary-section" id="about">
            <div class="triangle"></div>
            <div class="container">
                <div class="title">
                    <h1><?php echo e($aboutus->title); ?></h1>
                </div>
              
               <div>
               <p><?php echo $aboutus->details; ?></p>    
               </div>
              
            </div>
        </div>
        <!-- About us section end -->
        <div class="section secondary-section">
            <div class="triangle"></div>
            <div class="container centered">
                <?php if($aboutus->fileattach): ?>
                <a href="storage/upload/<?php echo e($aboutus->fileattach); ?>" target="_blank" class="button">
                <?php echo e($aboutus->filetitle); ?></a>
                <?php endif; ?>
            </div>
        </div>
        <!-- Client section start -->
        <!-- Client section start --><?php /**PATH D:\laravel_tests\newvision\resources\views/front/layouts/about.blade.php ENDPATH**/ ?>