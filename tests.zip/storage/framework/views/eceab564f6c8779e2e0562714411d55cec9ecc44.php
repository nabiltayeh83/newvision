<?php $__env->startSection('title', 'إدارة الخدمات'); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-12">

    <div class="panel panel-default">

        <div class="panel-heading">
            <form method="get" action="<?php echo e(asset('admin/services')); ?>" class="row">
                <div class="col-sm-3">
                <input name="key" id="key" type="text" required="required" class="form-control" placeholder="إبحث..">
                </div>
                <div class="col-sm-1">
                <button class="btn btn-primary" type="submit">إبحث</button>
                </div>
                <div class="col-sm-8 text-left">
                <a class="btn btn-success" href="<?php echo e(asset('admin/services/create')); ?>">
                <i class="glyphicon glyphicon-plus"></i> إضافة خدمة جديدة</a>
                </div>
            </form>
        </div>
    
<div class="panel-body">
<?php if(isset($key)): ?>
<h3>البحث عن / <?php echo e($key); ?></h3><br>
<?php endif; ?>

<div class="table-responsive">
<?php if(count($results) > 0): ?>
<table class="table table-striped table-boredered table-hover table-responsive">
    <thead>
    <tr>
        <th>#</th>
        <th>إسم المشروع</th>
        <th>العميل</th>
        <th>التصنيف</th>
        <th>التاريخ</th>
        <th>فعال</th>
        <th>الصورة</th>
        <th></th>
        <th></th>
    </tr>
    </thead>

    <?php $i=1; ?>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i++); ?></th>
        <td><?php echo e($r->projectname); ?></td>
        <td><?php echo e($r->customername); ?></td>
        <td><?php echo e($r->category->title); ?></td>
        <td><?php echo e(substr($r->created_at, 0, 10)); ?></td>
        <td><input type="checkbox" value="<?php echo e($r->id); ?>" class="cbActive" <?php echo e($r->is_active?"checked":""); ?>></td>
        <td><img src="<?php echo e(asset('storage/images/thumb/'.$r->image)); ?>" class="img-thumbnail" style="width:130px;"></td>
        <td><a href="<?php echo e(asset('admin/services/' . $r->id . '/edit')); ?>" class="btn btn-primary" title="تعديل">
        <span class="glyphicon glyphicon-edit"></span></a></td>
        <td><a href="<?php echo e(asset('admin/services/delete/' . $r->id)); ?>" class="btn Confirm btn-danger" title="حذف">
        <span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php echo e($results->links()); ?>

<?php else: ?>
<div>
عذراً... لا يوجد أي نتائج
</div>
<?php endif; ?>

</div>
</div>
</div>
</div>
</div>

<script>
    $(function(){
        $(".cbActive").click(function(){
            var id=$(this).val();
            $.get("/admin/services/active/"+id);
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tests\newvision\resources\views/back/services/index.blade.php ENDPATH**/ ?>