<div class="footer">
        <p> جميع الحقوق محفوظة - 
                <?php if(isset($sitesettings->title)): ?> 
                        <?php echo e($sitesettings->title); ?> 
                <?php endif; ?> <?php echo e(date('Y')); ?>  &copy;
        </p>
</div>


<div class="scrollup">
        <a href="#">
                <i class="icon-up-open"></i>
        </a>
</div><?php /**PATH D:\laravel_tests\newvision\resources\views/front/footer.blade.php ENDPATH**/ ?>